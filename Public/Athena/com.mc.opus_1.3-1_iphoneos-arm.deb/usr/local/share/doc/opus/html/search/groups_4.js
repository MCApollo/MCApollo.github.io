var searchData=
[
  ['opus_20custom',['Opus Custom',['../group__opus__custom.html',1,'']]],
  ['opus_20decoder',['Opus Decoder',['../group__opus__decoder.html',1,'']]],
  ['opus_20encoder',['Opus Encoder',['../group__opus__encoder.html',1,'']]],
  ['opus_20library_20information_20functions',['Opus library information functions',['../group__opus__libinfo.html',1,'']]],
  ['opus_20multistream_20api',['Opus Multistream API',['../group__opus__multistream.html',1,'']]]
];
