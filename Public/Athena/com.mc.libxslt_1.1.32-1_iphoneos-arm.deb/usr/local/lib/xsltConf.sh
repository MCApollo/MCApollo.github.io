#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/usr/local/lib"
XSLT_LIBS="-lxslt -L/home/cade/toolchain/SDK/usr/local/lib -lxml2  "
XSLT_INCLUDEDIR="-I/usr/local/include"
MODULE_VERSION="xslt-1.1.32"
