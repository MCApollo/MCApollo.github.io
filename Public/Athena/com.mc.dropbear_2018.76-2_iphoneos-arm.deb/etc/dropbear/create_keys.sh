#!/bin/bash

RSA_KEYFILE=/etc/dropbear/dropbear_rsa_host_key
DSS_KEYFILE=/etc/dropbear/dropbear_dss_host_key
LOG_FILE=/etc/dropbear/log

dropbearkey -t dss -f $DSS_KEYFILE > $LOG_FILE
dropbearkey -t rsa -f $RSA_KEYFILE > $LOG_FILE

echo "Done."
